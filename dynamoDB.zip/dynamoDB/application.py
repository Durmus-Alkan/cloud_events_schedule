# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 16:39:56 2020

@author: hp
"""

from flask import Flask, render_template, request

import boto3

application = Flask(__name__)
ACCESS_KEY_ID = 'AKIAZL6IYXCP6RAV4MC7'
ACCESS_SECRET_KEY = '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'
AWS_SESSION_TOKEN = 'FwoGZXIvYXdzEBUaDHiXR63f451C+fVW4CLJATOdeYYFp5Wj3GHPyDyUkF4xggM7jjOuP7X5+d9NiVTeTYm/kTk3444cgNzGtS6klfzYrkkkt0zT0ovFbOIonPcyl5gscA07Ov9ba8wZlhkNS4MkVItl55jWX0KTs0HBEMTfnMJ1k5/AeqwJYByZ5mYTSA4z6FVCwyeNpuuqkbidWs7TzYx/t46kmOWL6vRK7oqOdTNap7kCaXoBhWfw5AFKZyRO3T6QrPmbq1y4qPPqhCf2rOhnhFbZWMJnD8Bj5I+oIdWcoRBC3SiSwb34BTIt9P+BUrAdF1ovXYGrfg3Jc5pLGZdwC0jRH5l/ILtvYSo9hM73QClAz/6ZaWl7'
AWS_REGION = 'us-east-1'

dynamodb = boto3.resource('dynamodb',
                          aws_access_key_id=ACCESS_KEY_ID,
                          aws_secret_access_key=ACCESS_SECRET_KEY,
                          region_name=AWS_REGION)

from boto3.dynamodb.conditions import Key, Attr


@application.route('/')
def index():
    return render_template('index.html')


@application.route('/signup', methods=['post'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        table = dynamodb.Table('users')

        table.put_item(
            Item={
                'name': name,
                'email': email,
                'password': password
            }
        )
        msg = "Registration Complete. Please Login to your account !"

        return render_template('login.html', msg=msg)
    return render_template('index.html')


@application.route('/login')
def login():
    return render_template('login.html')


@application.route('/check', methods=['post'])
def check():
    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        table = dynamodb.Table('users')
        response = table.query(
            KeyConditionExpression=Key('email').eq(email)
        )
        items = response['Items']
        name = items[0]['name']
        print(items[0]['password'])
        if password == items[0]['password']:
            return render_template("home.html", name=name)
    return render_template("login.html")


@application.route('/home')
def home():
    return render_template('home.html')


if __name__ == "__main__":
    application.run(debug=True)
